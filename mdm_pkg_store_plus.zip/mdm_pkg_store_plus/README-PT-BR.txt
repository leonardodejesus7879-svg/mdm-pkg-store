MDM PKG STORE PLUS — GUIA EM PORTUGUÊS
======================================

Inclui:
- Catálogo com cartões e espaço para imagens de capa.
- Busca e filtro por categoria.
- Painel de administração para adicionar/remover itens.
- Campos de nome, categoria, versão, descrição, URL de PKG e imagem.
- Exportação/importação do catálogo em JSON.
- Salvamento local no navegador.

LIMITAÇÃO IMPORTANTE:
O painel salva alterações apenas no navegador/dispositivo atual. Para que visitantes diferentes vejam os mesmos itens, é preciso exportar o JSON e publicar as alterações, ou conectar um backend com autenticação e armazenamento. Esta versão não é um servidor de arquivos e não gera um PKG nativo para PS4.

USO PELO SAMSUNG M22:
1. Baixe e extraia o ZIP.
2. Abra index.html em um navegador para testar.
3. Toque em “Painel de administração”.
4. Preencha os dados do aplicativo. Use apenas links https/http válidos de arquivos que você pode distribuir.
5. Adicione a URL da imagem de capa (opcional).
6. Exporte o catálogo JSON para fazer backup.

PUBLICAR NO GITHUB PAGES:
1. Crie um repositório público no GitHub.
2. Envie index.html para a raiz.
3. Vá a Settings > Pages.
4. Escolha Deploy from a branch, branch main e pasta /(root), e salve.
5. Aguarde o GitHub mostrar a URL pública.
6. Ao atualizar o catálogo, importe o JSON no painel, exporte-o e, para publicação compartilhada persistente, será necessário atualizar a lista do site ou implementar um backend.

ARQUIVOS:
- index.html: a loja.
- README-PT-BR.txt: estas instruções.
